-- ============================================================
-- NexChat PHP — Database Schema
-- ============================================================
CREATE DATABASE IF NOT EXISTS nexchat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nexchat;

-- Rooms
CREATE TABLE IF NOT EXISTS rooms (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    room_id       VARCHAR(60) UNIQUE NOT NULL,
    host_sid      VARCHAR(64) NOT NULL,
    host_handle   VARCHAR(40) NOT NULL,
    host_color    VARCHAR(10) DEFAULT '#e8ff47',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at     TIMESTAMP NULL
) ENGINE=InnoDB;

-- Sessions (online users in rooms)
CREATE TABLE IF NOT EXISTS room_sessions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    sid         VARCHAR(64) UNIQUE NOT NULL,
    room_id     VARCHAR(60) NOT NULL,
    handle      VARCHAR(40) NOT NULL,
    display_name VARCHAR(40) NOT NULL,
    color       VARCHAR(10) DEFAULT '#4da3ff',
    role        ENUM('host','member') DEFAULT 'member',
    is_online   TINYINT(1) DEFAULT 1,
    is_typing   TINYINT(1) DEFAULT 0,
    last_seen   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Pending join requests
CREATE TABLE IF NOT EXISTS pending_requests (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    room_id      VARCHAR(60) NOT NULL,
    sid          VARCHAR(64) NOT NULL,
    handle       VARCHAR(40) NOT NULL,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status       ENUM('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB;

-- Messages
CREATE TABLE IF NOT EXISTS messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    msg_uuid    VARCHAR(36) UNIQUE NOT NULL,
    room_id     VARCHAR(60) NOT NULL,
    sender_sid  VARCHAR(64) NOT NULL,
    handle      VARCHAR(40) NOT NULL,
    display_name VARCHAR(40) NOT NULL,
    color       VARCHAR(10) DEFAULT '#4da3ff',
    role        ENUM('host','member') DEFAULT 'member',
    message     TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Read receipts
CREATE TABLE IF NOT EXISTS message_reads (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    msg_uuid   VARCHAR(36) NOT NULL,
    reader_sid VARCHAR(64) NOT NULL,
    read_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_read (msg_uuid, reader_sid)
) ENGINE=InnoDB;

-- Beeps
CREATE TABLE IF NOT EXISTS beeps (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    room_id      VARCHAR(60) NOT NULL,
    sender_sid   VARCHAR(64) NOT NULL,
    sender_name  VARCHAR(40) NOT NULL,
    receiver_sid VARCHAR(64) NOT NULL,
    is_seen      TINYINT(1) DEFAULT 0,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
