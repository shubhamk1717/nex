<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NexChat — Controlled Rooms</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- ══════════════════════════════════════ -->
<!--  SCREEN 1 — LANDING                   -->
<!-- ══════════════════════════════════════ -->
<div id="screen-landing" class="screen active">
    <div class="bg-mesh"></div>
    <div class="landing-wrap">
        <div class="brand">
            <div class="brand-icon">◈</div>
            <div class="brand-name">NexChat</div>
            <div class="brand-tag">Controlled Room System · PHP Edition</div>
        </div>
        <div class="landing-cards">
            <div class="choice-card" id="btn-go-create">
                <div class="card-icon">⊕</div>
                <div class="card-title">Create Chatroom</div>
                <div class="card-desc">Start a new room. You become the Host with full access control.</div>
                <div class="card-arrow">→</div>
            </div>
            <div class="choice-card" id="btn-go-join">
                <div class="card-icon">⊞</div>
                <div class="card-title">Join Chatroom</div>
                <div class="card-desc">Enter a Room ID and request access. Wait for host approval.</div>
                <div class="card-arrow">→</div>
            </div>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════ -->
<!--  SCREEN 2 — CREATE ROOM               -->
<!-- ══════════════════════════════════════ -->
<div id="screen-create" class="screen">
    <div class="bg-mesh"></div>
    <div class="form-wrap">
        <button class="back-btn" data-target="screen-landing">← Back</button>
        <div class="form-card">
            <div class="form-header">
                <span class="form-icon">⊕</span>
                <div>
                    <div class="form-title">Create Chatroom</div>
                    <div class="form-subtitle">You will be the Host of this room</div>
                </div>
            </div>
            <div class="field-group">
                <label>Your Handle</label>
                <input type="text" id="create-handle" placeholder="e.g. alpha_host" maxlength="20" autocomplete="off">
            </div>
            <div class="field-group">
                <label>Room ID</label>
                <input type="text" id="create-room-id" placeholder="e.g. ROOM-001 or myroom" maxlength="30" autocomplete="off">
                <div class="field-hint">Must be unique. Others use this to find your room.</div>
            </div>
            <div class="error-box" id="create-error"></div>
            <button class="btn-primary" id="btn-create">
                <span>Create &amp; Enter Room</span>
                <span class="btn-icon">◈</span>
            </button>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════ -->
<!--  SCREEN 3 — JOIN ROOM                 -->
<!-- ══════════════════════════════════════ -->
<div id="screen-join" class="screen">
    <div class="bg-mesh"></div>
    <div class="form-wrap">
        <button class="back-btn" data-target="screen-landing">← Back</button>
        <div class="form-card">
            <div class="form-header">
                <span class="form-icon">⊞</span>
                <div>
                    <div class="form-title">Join Chatroom</div>
                    <div class="form-subtitle">Request access to an existing room</div>
                </div>
            </div>
            <div class="field-group">
                <label>Your Handle</label>
                <input type="text" id="join-handle" placeholder="e.g. shadow_user" maxlength="20" autocomplete="off">
            </div>
            <div class="field-group">
                <label>Room ID</label>
                <input type="text" id="join-room-id" placeholder="Enter the exact Room ID" maxlength="30" autocomplete="off">
            </div>
            <div class="error-box" id="join-error"></div>
            <button class="btn-primary" id="btn-join">
                <span>Send Join Request</span>
                <span class="btn-icon">→</span>
            </button>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════ -->
<!--  SCREEN 4 — WAITING                   -->
<!-- ══════════════════════════════════════ -->
<div id="screen-waiting" class="screen">
    <div class="bg-mesh"></div>
    <div class="waiting-wrap">
        <div class="waiting-card">
            <div class="waiting-pulse">
                <div class="pulse-ring"></div>
                <div class="pulse-ring r2"></div>
                <div class="pulse-core">⏳</div>
            </div>
            <div class="waiting-title">Awaiting Approval</div>
            <div class="waiting-info">
                Your request to join <strong id="waiting-room-id">—</strong> has been sent to <strong id="waiting-host">—</strong>
            </div>
            <div class="waiting-status">Waiting for host to respond...</div>
            <button class="btn-cancel" id="btn-cancel-wait">Cancel Request</button>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════ -->
<!--  SCREEN 5 — CHAT ROOM                 -->
<!-- ══════════════════════════════════════ -->
<div id="screen-chat" class="screen">
    <div class="chat-layout">

        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-brand">
                <span class="brand-icon sm">◈</span>
                <span class="brand-name sm">NexChat</span>
            </div>

            <div class="room-info-block">
                <div class="ri-label">ROOM ID</div>
                <div class="ri-value" id="sb-room-id">—</div>
            </div>

            <!-- My Profile with editable name -->
            <div class="my-profile">
                <div class="profile-avatar" id="sb-avatar">?</div>
                <div class="profile-details">
                    <div class="profile-handle" id="sb-handle">—</div>
                    <div class="profile-role" id="sb-role">member</div>
                </div>
                <button class="edit-name-btn" id="btn-edit-name" title="Change display name">✏️</button>
            </div>

            <!-- HOST PANEL -->
            <div id="host-panel" class="host-panel hidden">
                <div class="panel-title">
                    <span>⚡ Host Panel</span>
                    <span class="pending-badge" id="pending-badge">0</span>
                </div>
                <div class="panel-section">
                    <div class="ps-label">PENDING REQUESTS</div>
                    <div id="pending-list" class="pending-list">
                        <div class="empty-state">No pending requests</div>
                    </div>
                </div>
                <div class="panel-section">
                    <div class="ps-label">MEMBERS</div>
                    <div id="member-list-host" class="member-list"></div>
                </div>
            </div>

            <!-- MEMBER PANEL -->
            <div id="member-panel" class="member-panel hidden">
                <div class="panel-section">
                    <div class="ps-label">MEMBERS</div>
                    <div id="member-list-user" class="member-list"></div>
                </div>
            </div>

            <div class="sidebar-footer">
                <button class="btn-leave" id="btn-leave">Leave Room</button>
            </div>
        </aside>

        <!-- MAIN CHAT -->
        <main class="chat-main">
            <div class="chat-topbar">
                <div class="topbar-left">
                    <span class="hash">#</span>
                    <span id="tb-room-id">room</span>
                    <span class="host-tag" id="tb-host-tag"></span>
                </div>
                <div class="topbar-right">
                    <span class="members-pill" id="tb-member-count">1 member</span>
                </div>
            </div>

            <div class="messages-wrap" id="messages-wrap">
                <div class="messages-inner" id="messages-inner"></div>
            </div>

            <div class="typing-bar" id="typing-bar"></div>

            <div class="input-bar">
                <div class="input-box">
                    <input type="text" id="msg-input" placeholder="Send a message..." maxlength="500" autocomplete="off">
                    <span class="char-left" id="char-left">500</span>
                </div>
                <button class="beep-btn" id="beep-btn" title="Send a Beep! 📳">📳</button>
                <button class="send-btn" id="send-btn" disabled>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                </button>
            </div>
        </main>
    </div>
</div>

<!-- ══════════════════════════════════════ -->
<!--  CHANGE NAME MODAL                    -->
<!-- ══════════════════════════════════════ -->
<div id="name-modal" class="modal-overlay hidden">
    <div class="modal-box">
        <div class="modal-title">✏️ Change Your Display Name</div>
        <div class="field-group">
            <label>New Display Name</label>
            <input type="text" id="new-name-input" maxlength="40" placeholder="Enter new name" autocomplete="off">
        </div>
        <div class="modal-actions">
            <button class="btn-cancel-modal" id="btn-cancel-name">Cancel</button>
            <button class="btn-save-name" id="btn-save-name">Save</button>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════ -->
<!--  INCOMING BEEP OVERLAY                -->
<!-- ══════════════════════════════════════ -->
<div id="beep-overlay" class="beep-overlay hidden">
    <div class="beep-card">
        <div class="beep-wave-anim">📳</div>
        <div class="beep-title" id="beep-from-name">Someone</div>
        <div class="beep-subtitle">sent you a BEEP!</div>
        <button class="btn-dismiss-beep" id="btn-dismiss-beep">Got it 👍</button>
    </div>
</div>

<!-- TOAST -->
<div id="toast" class="toast hidden"></div>

<script src="js/app.js"></script>
</body>
</html>
