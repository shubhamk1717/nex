<?php
// ============================================================
// NexChat PHP — Configuration
// ============================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'nexchat');

// Session & polling settings
define('POLL_TIMEOUT',  25);   // seconds for long-poll
define('MSG_HISTORY',   50);   // messages to load on join

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER, DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'DB error: ' . $e->getMessage()]));
}

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Generate a unique session ID for this browser tab
if (empty($_SESSION['sid'])) {
    $_SESSION['sid'] = bin2hex(random_bytes(16));
}

$MY_SID = $_SESSION['sid'];

// Avatar colors
$USER_COLORS = [
    '#FF6B6B','#4ECDC4','#45B7D1','#96CEB4','#FFEAA7',
    '#DDA0DD','#98D8C8','#F7DC6F','#BB8FCE','#85C1E9',
    '#F0A500','#E17055','#00B894','#6C5CE7','#FD79A8'
];

function nextColor(): string {
    global $USER_COLORS;
    static $idx = 0;
    $c = $USER_COLORS[$idx % count($USER_COLORS)];
    $idx++;
    return $c;
}

function nowStr(): string {
    return date('H:i');
}

function uuidv4(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0,0xffff), mt_rand(0,0xffff),
        mt_rand(0,0xffff),
        mt_rand(0,0x0fff)|0x4000,
        mt_rand(0,0x3fff)|0x8000,
        mt_rand(0,0xffff), mt_rand(0,0xffff), mt_rand(0,0xffff)
    );
}
?>
