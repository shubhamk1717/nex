// ============================================================
//  NexChat PHP — Client Logic (app.js)
// ============================================================

// ── State ───────────────────────────────────────────────────
let myHandle       = '';
let myDisplayName  = '';
let myRoom         = '';
let myRole         = '';
let myColor        = '';
let mySid          = '';

let lastMsgId      = 0;
let lastReadId     = 0;
let heartbeatTimer = null;
let waitPollTimer  = null;
let typingTimer    = null;
let isTyping       = false;

let renderedMsgIds  = new Set();   // DB ids already shown
let pendingSidMap   = {};          // req_id -> element  (host side)
let memberSidMap    = {};          // sid -> {handle, display_name}

let audioCtx = null;

// ── Audio ────────────────────────────────────────────────────
function getCtx() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
}

function playTone(freq, dur, type = 'sine', vol = 0.6) {
    try {
        const ctx  = getCtx();
        const osc  = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = type;
        osc.frequency.value = freq;
        gain.gain.setValueAtTime(vol, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + dur);
    } catch(e) {}
}

function playMsgSound()  { playTone(660, 0.08); }

function playBeepSound() {
    playTone(880, 0.12, 'square', 0.7);
    setTimeout(() => playTone(1100, 0.12, 'square', 0.7), 140);
    setTimeout(() => playTone(1320, 0.25, 'square', 0.7), 280);
    if (navigator.vibrate) navigator.vibrate([200, 80, 200, 80, 400]);
}

// ── Screen Management ────────────────────────────────────────
function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
}

// Back buttons
document.querySelectorAll('.back-btn').forEach(btn => {
    btn.addEventListener('click', () => showScreen(btn.dataset.target));
});

// Landing
document.getElementById('btn-go-create').addEventListener('click', () => showScreen('screen-create'));
document.getElementById('btn-go-join').addEventListener('click',   () => showScreen('screen-join'));

// ── CREATE ROOM ──────────────────────────────────────────────
document.getElementById('btn-create').addEventListener('click', doCreate);
document.getElementById('create-room-id').addEventListener('keydown', e => { if (e.key === 'Enter') doCreate(); });

async function doCreate() {
    const handle  = document.getElementById('create-handle').value.trim();
    const roomId  = document.getElementById('create-room-id').value.trim();
    const errBox  = document.getElementById('create-error');
    hideError(errBox);

    if (!handle) { showError(errBox, 'Please enter your handle.'); return; }
    if (!roomId)  { showError(errBox, 'Please enter a Room ID.'); return; }

    const res  = await post('create_room', { handle, room_id: roomId });
    if (!res.ok) { showError(errBox, res.error || 'Error creating room.'); return; }

    myHandle      = handle;
    myDisplayName = handle;
    myRoom        = res.room_id;
    myRole        = 'host';
    myColor       = res.color;
    enterChatScreen();
    appendSysMsg(`Room "${myRoom}" created. You are the Host.`);
}

// ── JOIN ROOM ────────────────────────────────────────────────
document.getElementById('btn-join').addEventListener('click', doJoin);
document.getElementById('join-room-id').addEventListener('keydown', e => { if (e.key === 'Enter') doJoin(); });

async function doJoin() {
    const handle = document.getElementById('join-handle').value.trim();
    const roomId = document.getElementById('join-room-id').value.trim();
    const errBox = document.getElementById('join-error');
    hideError(errBox);

    if (!handle) { showError(errBox, 'Please enter your handle.'); return; }
    if (!roomId)  { showError(errBox, 'Please enter a Room ID.'); return; }

    const res = await post('request_join', { handle, room_id: roomId });
    if (!res.ok) { showError(errBox, res.error || 'Error sending request.'); return; }

    document.getElementById('waiting-room-id').textContent = res.room_id;
    document.getElementById('waiting-host').textContent    = res.host_handle;
    myHandle = handle;
    myRoom   = res.room_id;
    showScreen('screen-waiting');
    startWaitPoll();
}

// Cancel wait
document.getElementById('btn-cancel-wait').addEventListener('click', async () => {
    clearInterval(waitPollTimer);
    await post('cancel_join', {});
    showScreen('screen-landing');
    myHandle = ''; myRoom = '';
});

// ── WAIT POLL ────────────────────────────────────────────────
function startWaitPoll() {
    waitPollTimer = setInterval(async () => {
        const res = await get('poll_join');
        if (res.status === 'approved') {
            clearInterval(waitPollTimer);
            myRole        = 'member';
            myColor       = res.color;
            myDisplayName = myHandle;
            enterChatScreen();
            if (res.history && res.history.length) {
                appendSysMsg(`Last ${res.history.length} message(s) loaded`);
                res.history.forEach(m => renderMessage(m));
                if (res.history.length) lastMsgId = Math.max(...res.history.map(m => parseInt(m.id)||0));
                lastReadId = lastMsgId;
            } else {
                appendSysMsg('No previous messages. Say hello! 👋');
            }
            scrollBottom();
            markVisibleRead();
        } else if (res.status === 'rejected') {
            clearInterval(waitPollTimer);
            showScreen('screen-join');
            showError(document.getElementById('join-error'), res.reason || 'Access denied.');
            myHandle = ''; myRoom = '';
        }
    }, 2000);
}

// ── ENTER CHAT ───────────────────────────────────────────────
function enterChatScreen() {
    document.getElementById('sb-room-id').textContent  = myRoom;
    document.getElementById('sb-handle').textContent   = myDisplayName;
    document.getElementById('sb-role').textContent     = myRole === 'host' ? '♛ Host' : '● Member';
    document.getElementById('sb-avatar').textContent   = myDisplayName[0].toUpperCase();
    document.getElementById('sb-avatar').style.background   = myColor + '22';
    document.getElementById('sb-avatar').style.color        = myColor;
    document.getElementById('sb-avatar').style.borderColor  = myColor + '66';

    document.getElementById('tb-room-id').textContent  = myRoom;
    const htag = document.getElementById('tb-host-tag');
    htag.textContent = myRole === 'host' ? '♛ You are Host' : '';

    if (myRole === 'host') {
        document.getElementById('host-panel').classList.remove('hidden');
        document.getElementById('member-panel').classList.add('hidden');
    } else {
        document.getElementById('host-panel').classList.add('hidden');
        document.getElementById('member-panel').classList.remove('hidden');
    }

    document.getElementById('messages-inner').innerHTML = '';
    document.getElementById('typing-bar').innerHTML    = '';
    document.getElementById('pending-list').innerHTML  = '<div class="empty-state">No pending requests</div>';
    document.getElementById('member-list-host').innerHTML = '';
    document.getElementById('member-list-user').innerHTML = '';

    showScreen('screen-chat');
    document.getElementById('msg-input').focus();

    if (myRole === 'host') appendSysMsg('Welcome! You control who enters this room.');

    startHeartbeat();
}

// ── HEARTBEAT ────────────────────────────────────────────────
function startHeartbeat() {
    heartbeatTimer = setInterval(runHeartbeat, 1500);
}

async function runHeartbeat() {
    const res = await get(`heartbeat&last_msg_id=${lastMsgId}&last_read_id=${lastReadId}`);
    if (!res.ok) return;

    for (const ev of (res.events || [])) {
        switch (ev.type) {

            case 'new_messages':
                ev.messages.forEach(m => {
                    if (!renderedMsgIds.has(m.id)) renderMessage(m);
                });
                if (ev.messages.length) {
                    const maxId = Math.max(...ev.messages.map(m => parseInt(m.id)));
                    if (maxId > lastMsgId) lastMsgId = maxId;
                    scrollBottom();
                    playMsgSound();
                    markVisibleRead();
                }
                break;

            case 'read_updates':
                ev.updates.forEach(u => {
                    const el = document.querySelector(`.msg-tick[data-uuid="${u.msg_uuid}"]`);
                    if (el && parseInt(u.read_count) > 1) {
                        el.classList.add('read');
                        el.textContent = '✓✓';
                        el.title = 'Read';
                    }
                });
                break;

            case 'typing':
                const bar = document.getElementById('typing-bar');
                if (ev.typers && ev.typers.length) {
                    const names = ev.typers.join(', ');
                    bar.innerHTML = `<div class="typing-dots"><span></span><span></span><span></span></div><span>${esc(names)} is typing...</span>`;
                } else {
                    bar.innerHTML = '';
                }
                break;

            case 'beeps':
                ev.beeps.forEach(b => {
                    if (b.sender_name === '__kicked') {
                        // This user was kicked
                        showToast('🚫 You have been removed by the host.', 'error');
                        setTimeout(() => { clearInterval(heartbeatTimer); resetState(); showScreen('screen-landing'); }, 2500);
                    } else {
                        showIncomingBeep(b.sender_name);
                    }
                });
                break;

            case 'pending_list':
                if (myRole === 'host') renderPendingList(ev.pending, ev.count);
                break;

            case 'member_list':
                renderMemberList(ev.members);
                document.getElementById('tb-member-count').textContent =
                    `${ev.count} member${ev.count !== 1 ? 's' : ''}`;
                break;

            case 'room_closed':
                showToast('🔒 ' + ev.message, 'error');
                setTimeout(() => { clearInterval(heartbeatTimer); resetState(); showScreen('screen-landing'); }, 2500);
                break;
        }
    }
}

// ── MESSAGES ─────────────────────────────────────────────────
function renderMessage(m) {
    if (m.sender_sid === 'system' || m.role === 'member' && m.handle === m.display_name && m.message.includes('has ')) {
        // Check if it looks like a system message
        if (m.sender_sid === 'system') {
            appendSysMsg(m.message);
            if (m.id) renderedMsgIds.add(m.id);
            return;
        }
    }

    const isMe   = (m.handle === myHandle);
    const isHost = (m.role === 'host');
    const color  = m.color || '#8b8fa8';
    const dispName = m.display_name || m.handle;

    const row = document.createElement('div');
    row.className = 'msg-row';
    if (m.id) { row.dataset.id = m.id; renderedMsgIds.add(parseInt(m.id)); }
    if (m.msg_uuid) row.dataset.uuid = m.msg_uuid;

    // Time format
    const ts = m.created_at ? new Date(m.created_at.replace(' ','T')).toLocaleTimeString('en',{hour:'2-digit',minute:'2-digit'}) : nowStr();

    // Read tick (only for my messages)
    const tickHtml = isMe
        ? `<div class="msg-read-status"><span class="tick msg-tick" data-uuid="${m.msg_uuid||''}" title="Sent">✓</span></div>`
        : '';

    row.innerHTML = `
        <div class="msg-ava" style="background:${color}20;color:${color};border:2px solid ${color}40">${dispName[0].toUpperCase()}</div>
        <div class="msg-body">
            <div class="msg-meta">
                <span class="msg-author" style="color:${color}">${esc(dispName)}</span>
                ${isHost ? '<span class="msg-crown">♛</span>' : ''}
                ${isMe ? '<span style="color:var(--t3);font-size:11px;font-family:var(--ff-mono)">(you)</span>' : ''}
                <span class="msg-time">${ts}</span>
            </div>
            <div class="msg-text">${esc(m.message)}</div>
            ${tickHtml}
        </div>`;

    document.getElementById('messages-inner').appendChild(row);
}

// ── SEND MESSAGE ─────────────────────────────────────────────
const msgInput = document.getElementById('msg-input');
const sendBtn  = document.getElementById('send-btn');
const charLeft = document.getElementById('char-left');

sendBtn.addEventListener('click', sendMsg);
msgInput.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg(); }
});

msgInput.addEventListener('input', () => {
    const rem = 500 - msgInput.value.length;
    charLeft.textContent = rem;
    charLeft.className = 'char-left' + (rem < 50 ? ' danger' : rem < 100 ? ' warn' : '');
    sendBtn.disabled = msgInput.value.length === 0;

    if (!isTyping) { isTyping = true; post('typing', { is_typing: 1 }); }
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => { isTyping = false; post('typing', { is_typing: 0 }); }, 1500);
});

async function sendMsg() {
    const msg = msgInput.value.trim();
    if (!msg) return;

    msgInput.value = ''; charLeft.textContent = '500'; charLeft.className = 'char-left';
    sendBtn.disabled = true;
    if (isTyping) { isTyping = false; clearTimeout(typingTimer); post('typing', { is_typing: 0 }); }

    const res = await post('send_message', { message: msg });
    if (res.ok) {
        if (res.msg_id > lastMsgId) lastMsgId = res.msg_id;
        if (lastReadId === 0) lastReadId = res.msg_id;
    }
    msgInput.focus();
}

// ── MARK READ ────────────────────────────────────────────────
function markVisibleRead() {
    const rows = document.querySelectorAll('.msg-row[data-uuid]');
    const uuids = [];
    rows.forEach(row => {
        if (row.querySelector('.msg-tick')) return; // my own msg
        const uuid = row.dataset.uuid;
        if (uuid) uuids.push(uuid);
    });
    if (uuids.length) post('mark_read', { uuids: JSON.stringify(uuids) });
    if (lastMsgId > lastReadId) lastReadId = lastMsgId;
}

// ── BEEP ─────────────────────────────────────────────────────
const beepBtn = document.getElementById('beep-btn');
beepBtn.addEventListener('click', () => {
    // Show member picker if multiple members
    const members = Object.values(memberSidMap).filter(m => m.handle !== myHandle);
    if (!members.length) { showToast('No one else in the room to beep!', 'error'); return; }
    if (members.length === 1) {
        sendBeepTo(members[0].sid, members[0].display_name);
    } else {
        showBeepPicker(members);
    }
});

function showBeepPicker(members) {
    // Simple quick-pick via toast (for small member counts)
    // For now beep all
    members.forEach(m => sendBeepTo(m.sid, m.display_name));
}

async function sendBeepTo(receiverSid, receiverName) {
    beepBtn.classList.add('beeping');
    setTimeout(() => beepBtn.classList.remove('beeping'), 400);
    if (navigator.vibrate) navigator.vibrate(80);

    await post('send_beep', { receiver_sid: receiverSid });
    showToast(`📳 Beeped ${esc(receiverName)}!`, 'info');
}

function showIncomingBeep(senderName) {
    playBeepSound();
    document.getElementById('beep-from-name').textContent = senderName;
    document.getElementById('beep-overlay').classList.remove('hidden');
    setTimeout(dismissBeep, 4000);
}

function dismissBeep() {
    document.getElementById('beep-overlay').classList.add('hidden');
}
document.getElementById('btn-dismiss-beep').addEventListener('click', dismissBeep);

// ── PENDING REQUESTS (HOST) ───────────────────────────────────
function renderPendingList(pending, count) {
    document.getElementById('pending-badge').textContent = count;
    const list = document.getElementById('pending-list');

    // Remove items no longer pending
    const currentIds = new Set(pending.map(p => p.id));
    list.querySelectorAll('.pending-item').forEach(el => {
        if (!currentIds.has(el.dataset.reqId)) el.remove();
    });

    // Add new ones
    pending.forEach(req => {
        if (list.querySelector(`[data-req-id="${req.id}"]`)) return; // already rendered
        list.querySelectorAll('.empty-state').forEach(e => e.remove());

        const el = document.createElement('div');
        el.className = 'pending-item';
        el.dataset.reqId = req.id;
        el.innerHTML = `
            <div>
                <div class="pending-handle">${esc(req.handle)}</div>
                <div class="pending-time">Requested at ${req.requested_at}</div>
            </div>
            <div class="pending-actions">
                <button class="btn-approve">✓ Approve</button>
                <button class="btn-reject">✕ Reject</button>
            </div>`;

        el.querySelector('.btn-approve').addEventListener('click', async () => {
            await post('approve_user', { req_id: req.id });
            el.remove();
            if (!list.children.length) list.innerHTML = '<div class="empty-state">No pending requests</div>';
        });
        el.querySelector('.btn-reject').addEventListener('click', async () => {
            await post('reject_user', { req_id: req.id });
            el.remove();
            if (!list.children.length) list.innerHTML = '<div class="empty-state">No pending requests</div>';
        });

        list.appendChild(el);
    });
}

// ── MEMBER LIST ───────────────────────────────────────────────
function renderMemberList(members) {
    memberSidMap = {};
    members.forEach(m => { memberSidMap[m.sid] = m; });

    renderMemberListEl('member-list-host', members, true);
    renderMemberListEl('member-list-user', members, false);
}

function renderMemberListEl(containerId, members, isHostView) {
    const el = document.getElementById(containerId);
    el.innerHTML = '';
    members.forEach(m => {
        const isMe   = m.handle === myHandle;
        const isHost = m.role  === 'host';
        const div = document.createElement('div');
        div.className = 'member-item';
        div.innerHTML = `
            <div class="member-dot"></div>
            <span class="member-name ${isMe?'me':''}">${esc(m.display_name||m.handle)}${isMe?' (you)':''}</span>
            ${isHost ? '<span class="host-crown" title="Host">♛</span>' : ''}
            ${!isMe ? `<button class="beep-member-btn" title="Beep ${esc(m.display_name||m.handle)}" data-sid="${m.sid}" data-name="${esc(m.display_name||m.handle)}">📳</button>` : ''}
            ${isHostView && !isHost && myRole==='host' ? `<button class="kick-btn" title="Kick" data-sid="${m.sid}">✕</button>` : ''}
        `;
        el.appendChild(div);
    });

    // Beep member buttons
    el.querySelectorAll('.beep-member-btn').forEach(btn => {
        btn.addEventListener('click', () => sendBeepTo(btn.dataset.sid, btn.dataset.name));
    });

    // Kick buttons
    if (isHostView && myRole === 'host') {
        el.querySelectorAll('.kick-btn').forEach(btn => {
            btn.addEventListener('click', () => post('kick_user', { target_sid: btn.dataset.sid }));
        });
    }
}

// ── CHANGE DISPLAY NAME ───────────────────────────────────────
document.getElementById('btn-edit-name').addEventListener('click', () => {
    document.getElementById('new-name-input').value = myDisplayName;
    document.getElementById('name-modal').classList.remove('hidden');
    document.getElementById('new-name-input').focus();
});

document.getElementById('btn-cancel-name').addEventListener('click', () => {
    document.getElementById('name-modal').classList.add('hidden');
});

document.getElementById('btn-save-name').addEventListener('click', saveName);
document.getElementById('new-name-input').addEventListener('keydown', e => { if (e.key === 'Enter') saveName(); });

async function saveName() {
    const newName = document.getElementById('new-name-input').value.trim();
    if (!newName) return;

    const res = await post('change_name', { display_name: newName });
    if (res.ok) {
        myDisplayName = res.display_name;
        document.getElementById('sb-handle').textContent = myDisplayName;
        document.getElementById('sb-avatar').textContent = myDisplayName[0].toUpperCase();
        document.getElementById('name-modal').classList.add('hidden');
        showToast(`✅ Name changed to "${esc(myDisplayName)}"`, 'success');
    } else {
        showToast('Failed to change name', 'error');
    }
}

// ── LEAVE ────────────────────────────────────────────────────
document.getElementById('btn-leave').addEventListener('click', async () => {
    clearInterval(heartbeatTimer);
    await post('leave', {});
    resetState();
    showScreen('screen-landing');
});

// ── HELPERS ──────────────────────────────────────────────────
function appendSysMsg(text) {
    const el = document.createElement('div');
    el.className = 'sys-msg';
    el.textContent = text;
    document.getElementById('messages-inner').appendChild(el);
}

function scrollBottom() {
    const wrap = document.getElementById('messages-wrap');
    wrap.scrollTop = wrap.scrollHeight;
}

function showError(box, msg) { box.textContent = msg; box.classList.add('visible'); }
function hideError(box)      { box.textContent = ''; box.classList.remove('visible'); }

function resetState() {
    myHandle = ''; myDisplayName = ''; myRoom = '';
    myRole = ''; myColor = ''; lastMsgId = 0; lastReadId = 0;
    renderedMsgIds.clear(); memberSidMap = {};
    isTyping = false; clearTimeout(typingTimer); clearInterval(heartbeatTimer);
}

let toastTimer = null;
function showToast(msg, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.className = `toast ${type}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.add('hidden'), 3500);
}

function nowStr() {
    return new Date().toLocaleTimeString('en', {hour:'2-digit',minute:'2-digit'});
}

function esc(text) {
    const d = document.createElement('div');
    d.appendChild(document.createTextNode(String(text)));
    return d.innerHTML;
}

// ── API Utilities ─────────────────────────────────────────────
async function post(action, data) {
    try {
        const fd = new FormData();
        fd.append('action', action);
        Object.entries(data).forEach(([k,v]) => fd.append(k, v));
        const r = await fetch('api.php', { method: 'POST', body: fd });
        return await r.json();
    } catch(e) { return { ok: false, error: 'Network error' }; }
}

async function get(actionAndParams) {
    try {
        const r = await fetch(`api.php?action=${actionAndParams}`);
        return await r.json();
    } catch(e) { return { ok: false, events: [] }; }
}

// ── Init: check if session already in room ────────────────────
(async () => {
    const res = await get('session_info');
    if (res.in_room) {
        myHandle      = res.handle;
        myDisplayName = res.display_name;
        myRoom        = res.room_id;
        myRole        = res.role;
        myColor       = res.color;
        mySid         = res.sid;
        enterChatScreen();
        showToast('Reconnected to room.', 'success');
    }
})();
