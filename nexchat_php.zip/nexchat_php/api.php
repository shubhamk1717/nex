<?php
// ============================================================
// NexChat PHP — API Handler (api.php)
// ============================================================
require_once 'config.php';
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store');

$action = $_REQUEST['action'] ?? '';

// ── Heartbeat: keep session alive, return events ──────────
if ($action === 'heartbeat') {
    if (empty($_SESSION['room_id'])) {
        echo json_encode(['ok' => false, 'events' => []]);
        exit;
    }
    $sid     = $MY_SID;
    $room_id = $_SESSION['room_id'];

    // Update last_seen
    $pdo->prepare("UPDATE room_sessions SET last_seen=NOW() WHERE sid=?")->execute([$sid]);

    // Mark offline sessions (not seen for 15s)
    $pdo->prepare("UPDATE room_sessions SET is_online=0 WHERE room_id=? AND last_seen < DATE_SUB(NOW(), INTERVAL 15 SECOND)")->execute([$room_id]);

    $events = [];

    // New messages since last_msg_id
    $last_msg_id = (int)($_REQUEST['last_msg_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM messages WHERE room_id=? AND id > ? ORDER BY id ASC LIMIT 50");
    $stmt->execute([$room_id, $last_msg_id]);
    $new_msgs = $stmt->fetchAll();
    if ($new_msgs) {
        // Add read counts
        foreach ($new_msgs as &$msg) {
            $rs = $pdo->prepare("SELECT COUNT(*) as c FROM message_reads WHERE msg_uuid=?");
            $rs->execute([$msg['msg_uuid']]);
            $msg['read_count'] = (int)$rs->fetch()['c'];
        }
        $events[] = ['type' => 'new_messages', 'messages' => $new_msgs];
    }

    // Read receipt updates (my sent messages that got read)
    $last_read_check = (int)($_REQUEST['last_read_id'] ?? 0);
    if ($last_read_check > 0) {
        $stmt = $pdo->prepare("
            SELECT m.msg_uuid, m.id, COUNT(mr.reader_sid) as read_count
            FROM messages m
            LEFT JOIN message_reads mr ON m.msg_uuid = mr.msg_uuid
            WHERE m.room_id=? AND m.sender_sid=? AND m.id >= ?
            GROUP BY m.msg_uuid, m.id
        ");
        $stmt->execute([$room_id, $sid, max(1, $last_read_check - 20)]);
        $read_updates = $stmt->fetchAll();
        if ($read_updates) {
            $events[] = ['type' => 'read_updates', 'updates' => $read_updates];
        }
    }

    // Typing indicators
    $stmt = $pdo->prepare("SELECT handle, display_name FROM room_sessions WHERE room_id=? AND sid != ? AND is_online=1 AND last_seen > DATE_SUB(NOW(), INTERVAL 4 SECOND)");
    // We use a typing flag column check below
    $stmt2 = $pdo->prepare("SELECT handle, display_name FROM room_sessions WHERE room_id=? AND sid != ? AND is_typing=1 AND last_seen > DATE_SUB(NOW(), INTERVAL 4 SECOND)");
    $stmt2->execute([$room_id, $sid]);
    $typers = $stmt2->fetchAll();
    $events[] = ['type' => 'typing', 'typers' => array_column($typers, 'display_name')];

    // Beeps for me
    $bstmt = $pdo->prepare("SELECT * FROM beeps WHERE receiver_sid=? AND is_seen=0 ORDER BY created_at ASC");
    $bstmt->execute([$sid]);
    $beeps = $bstmt->fetchAll();
    if ($beeps) {
        $events[] = ['type' => 'beeps', 'beeps' => $beeps];
        $pdo->prepare("UPDATE beeps SET is_seen=1 WHERE receiver_sid=?")->execute([$sid]);
    }

    // Pending requests (host only)
    if ($_SESSION['role'] === 'host') {
        $pstmt = $pdo->prepare("SELECT * FROM pending_requests WHERE room_id=? AND status='pending' ORDER BY requested_at ASC");
        $pstmt->execute([$room_id]);
        $pending = $pstmt->fetchAll();
        $events[] = ['type' => 'pending_list', 'pending' => $pending, 'count' => count($pending)];
    }

    // Member list
    $mstmt = $pdo->prepare("SELECT sid, handle, display_name, color, role, is_online FROM room_sessions WHERE room_id=? AND is_online=1 ORDER BY role DESC, display_name ASC");
    $mstmt->execute([$room_id]);
    $members = $mstmt->fetchAll();
    $events[] = ['type' => 'member_list', 'members' => $members, 'count' => count($members)];

    // Room closed check
    $rstmt = $pdo->prepare("SELECT closed_at FROM rooms WHERE room_id=?");
    $rstmt->execute([$room_id]);
    $room = $rstmt->fetch();
    if (!$room || $room['closed_at']) {
        $events[] = ['type' => 'room_closed', 'message' => 'Host has left. Room is now closed.'];
    }

    echo json_encode(['ok' => true, 'events' => $events]);
    exit;
}

// ── Create Room ───────────────────────────────────────────
if ($action === 'create_room') {
    $handle  = trim($_POST['handle'] ?? '');
    $room_id = trim($_POST['room_id'] ?? '');

    if (!$handle || !$room_id) {
        echo json_encode(['ok' => false, 'error' => 'Handle and Room ID are required.']); exit;
    }
    if (strlen($handle) > 40 || strlen($room_id) > 60) {
        echo json_encode(['ok' => false, 'error' => 'Handle or Room ID too long.']); exit;
    }

    // Check duplicate room
    $stmt = $pdo->prepare("SELECT id FROM rooms WHERE room_id=? AND closed_at IS NULL");
    $stmt->execute([$room_id]);
    if ($stmt->fetch()) {
        echo json_encode(['ok' => false, 'error' => "Room \"$room_id\" is already active. Choose a different Room ID."]); exit;
    }

    $color = nextColor();
    $sid   = $MY_SID;

    // Insert room
    $pdo->prepare("INSERT INTO rooms (room_id, host_sid, host_handle, host_color) VALUES (?,?,?,?)")
        ->execute([$room_id, $sid, $handle, $color]);

    // Insert session
    $pdo->prepare("DELETE FROM room_sessions WHERE sid=?")->execute([$sid]);
    $pdo->prepare("INSERT INTO room_sessions (sid, room_id, handle, display_name, color, role) VALUES (?,?,?,?,?,'host')")
        ->execute([$sid, $room_id, $handle, $handle, $color]);

    $_SESSION['room_id']      = $room_id;
    $_SESSION['handle']       = $handle;
    $_SESSION['display_name'] = $handle;
    $_SESSION['role']         = 'host';
    $_SESSION['color']        = $color;

    echo json_encode(['ok' => true, 'room_id' => $room_id, 'handle' => $handle, 'color' => $color]);
    exit;
}

// ── Request Join ─────────────────────────────────────────
if ($action === 'request_join') {
    $handle  = trim($_POST['handle'] ?? '');
    $room_id = trim($_POST['room_id'] ?? '');

    if (!$handle || !$room_id) {
        echo json_encode(['ok' => false, 'error' => 'Handle and Room ID are required.']); exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM rooms WHERE room_id=? AND closed_at IS NULL");
    $stmt->execute([$room_id]);
    $room = $stmt->fetch();
    if (!$room) {
        echo json_encode(['ok' => false, 'error' => "Room \"$room_id\" does not exist or is closed."]); exit;
    }

    // Check duplicate handle
    $stmt = $pdo->prepare("SELECT id FROM room_sessions WHERE room_id=? AND handle=? AND is_online=1");
    $stmt->execute([$room_id, $handle]);
    if ($stmt->fetch()) {
        echo json_encode(['ok' => false, 'error' => "Handle \"$handle\" is already taken in this room."]); exit;
    }

    $stmt = $pdo->prepare("SELECT id FROM pending_requests WHERE room_id=? AND handle=? AND status='pending'");
    $stmt->execute([$room_id, $handle]);
    if ($stmt->fetch()) {
        echo json_encode(['ok' => false, 'error' => "A request with this handle is already pending."]); exit;
    }

    $sid = $MY_SID;
    $pdo->prepare("DELETE FROM pending_requests WHERE sid=?")->execute([$sid]);
    $pdo->prepare("INSERT INTO pending_requests (room_id, sid, handle) VALUES (?,?,?)")
        ->execute([$room_id, $sid, $handle]);

    $_SESSION['pending_room'] = $room_id;
    $_SESSION['pending_handle'] = $handle;

    echo json_encode(['ok' => true, 'room_id' => $room_id, 'host_handle' => $room['host_handle']]);
    exit;
}

// ── Poll Join Status (for waiting screen) ─────────────────
if ($action === 'poll_join') {
    $sid     = $MY_SID;
    $room_id = $_SESSION['pending_room'] ?? '';
    $handle  = $_SESSION['pending_handle'] ?? '';

    if (!$room_id) {
        echo json_encode(['status' => 'error', 'error' => 'No pending request.']); exit;
    }

    // Check room closed
    $rstmt = $pdo->prepare("SELECT closed_at FROM rooms WHERE room_id=?");
    $rstmt->execute([$room_id]);
    $room = $rstmt->fetch();
    if (!$room || $room['closed_at']) {
        echo json_encode(['status' => 'rejected', 'reason' => 'Room was closed.']); exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM pending_requests WHERE sid=? AND room_id=?");
    $stmt->execute([$sid, $room_id]);
    $req = $stmt->fetch();

    if (!$req) {
        // Check if directly approved
        $asmt = $pdo->prepare("SELECT * FROM room_sessions WHERE sid=? AND room_id=?");
        $asmt->execute([$sid, $room_id]);
        $sess = $asmt->fetch();
        if ($sess) {
            $_SESSION['room_id']      = $room_id;
            $_SESSION['handle']       = $sess['handle'];
            $_SESSION['display_name'] = $sess['display_name'];
            $_SESSION['role']         = 'member';
            $_SESSION['color']        = $sess['color'];
            unset($_SESSION['pending_room'], $_SESSION['pending_handle']);

            // Load history
            $hstmt = $pdo->prepare("SELECT * FROM messages WHERE room_id=? ORDER BY id DESC LIMIT " . MSG_HISTORY);
            $hstmt->execute([$room_id]);
            $history = array_reverse($hstmt->fetchAll());

            echo json_encode(['status' => 'approved', 'color' => $sess['color'], 'history' => $history]);
            exit;
        }
        echo json_encode(['status' => 'rejected', 'reason' => 'Request was not found.']); exit;
    }

    if ($req['status'] === 'approved') {
        $color = nextColor();
        $pdo->prepare("DELETE FROM room_sessions WHERE sid=?")->execute([$sid]);
        $pdo->prepare("INSERT INTO room_sessions (sid, room_id, handle, display_name, color, role) VALUES (?,?,?,?,?,'member')")
            ->execute([$sid, $room_id, $handle, $handle, $color]);

        $_SESSION['room_id']      = $room_id;
        $_SESSION['handle']       = $handle;
        $_SESSION['display_name'] = $handle;
        $_SESSION['role']         = 'member';
        $_SESSION['color']        = $color;
        unset($_SESSION['pending_room'], $_SESSION['pending_handle']);

        // Insert join system message
        $pdo->prepare("INSERT INTO messages (msg_uuid, room_id, sender_sid, handle, display_name, color, role, message) VALUES (?,'system','system',?,?,'#505670','member',?)")
            ->execute([uuidv4(), $handle, $handle, "$handle has joined the room."]);

        $hstmt = $pdo->prepare("SELECT * FROM messages WHERE room_id=? ORDER BY id DESC LIMIT " . MSG_HISTORY);
        $hstmt->execute([$room_id]);
        $history = array_reverse($hstmt->fetchAll());

        echo json_encode(['status' => 'approved', 'color' => $color, 'history' => $history]);
        exit;
    }

    if ($req['status'] === 'rejected') {
        $pdo->prepare("DELETE FROM pending_requests WHERE sid=?")->execute([$sid]);
        unset($_SESSION['pending_room'], $_SESSION['pending_handle']);
        echo json_encode(['status' => 'rejected', 'reason' => 'The host has denied your request.']);
        exit;
    }

    echo json_encode(['status' => 'pending']);
    exit;
}

// ── Approve User ─────────────────────────────────────────
if ($action === 'approve_user') {
    $req_id  = (int)($_POST['req_id'] ?? 0);
    $room_id = $_SESSION['room_id'] ?? '';
    if ($_SESSION['role'] !== 'host' || !$room_id) {
        echo json_encode(['ok' => false, 'error' => 'Unauthorized']); exit;
    }
    $pdo->prepare("UPDATE pending_requests SET status='approved' WHERE id=? AND room_id=?")
        ->execute([$req_id, $room_id]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Reject User ──────────────────────────────────────────
if ($action === 'reject_user') {
    $req_id  = (int)($_POST['req_id'] ?? 0);
    $room_id = $_SESSION['room_id'] ?? '';
    if ($_SESSION['role'] !== 'host' || !$room_id) {
        echo json_encode(['ok' => false, 'error' => 'Unauthorized']); exit;
    }
    $pdo->prepare("UPDATE pending_requests SET status='rejected' WHERE id=? AND room_id=?")
        ->execute([$req_id, $room_id]);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Send Message ─────────────────────────────────────────
if ($action === 'send_message') {
    $room_id = $_SESSION['room_id'] ?? '';
    $sid     = $MY_SID;
    $message = trim($_POST['message'] ?? '');

    if (!$room_id || !$message) {
        echo json_encode(['ok' => false]); exit;
    }

    $handle       = $_SESSION['handle'];
    $display_name = $_SESSION['display_name'];
    $color        = $_SESSION['color'];
    $role         = $_SESSION['role'];
    $uuid         = uuidv4();

    $pdo->prepare("INSERT INTO messages (msg_uuid, room_id, sender_sid, handle, display_name, color, role, message) VALUES (?,?,?,?,?,?,?,?)")
        ->execute([$uuid, $room_id, $sid, $handle, $display_name, $color, $role, $message]);

    $stmt = $pdo->prepare("SELECT id FROM messages WHERE msg_uuid=?");
    $stmt->execute([$uuid]);
    $msg_id = $stmt->fetch()['id'];

    // Auto-mark as read for sender
    $pdo->prepare("INSERT IGNORE INTO message_reads (msg_uuid, reader_sid) VALUES (?,?)")->execute([$uuid, $sid]);

    echo json_encode(['ok' => true, 'msg_id' => $msg_id, 'msg_uuid' => $uuid]);
    exit;
}

// ── Mark Messages Read ────────────────────────────────────
if ($action === 'mark_read') {
    $sid      = $MY_SID;
    $room_id  = $_SESSION['room_id'] ?? '';
    $msg_uuids = json_decode($_POST['uuids'] ?? '[]', true);
    if (!$room_id || !$msg_uuids) { echo json_encode(['ok' => true]); exit; }

    foreach ($msg_uuids as $uuid) {
        $pdo->prepare("INSERT IGNORE INTO message_reads (msg_uuid, reader_sid) VALUES (?,?)")->execute([$uuid, $sid]);
    }
    echo json_encode(['ok' => true]);
    exit;
}

// ── Typing ────────────────────────────────────────────────
if ($action === 'typing') {
    $sid      = $MY_SID;
    $room_id  = $_SESSION['room_id'] ?? '';
    $is_typing = (int)($_POST['is_typing'] ?? 0);
    if ($room_id) {
        // Add is_typing column check (column added dynamically)
        try {
            $pdo->prepare("UPDATE room_sessions SET is_typing=? WHERE sid=?")->execute([$is_typing, $sid]);
        } catch (Exception $e) {}
    }
    echo json_encode(['ok' => true]);
    exit;
}

// ── Send Beep ─────────────────────────────────────────────
if ($action === 'send_beep') {
    $sid         = $MY_SID;
    $room_id     = $_SESSION['room_id'] ?? '';
    $receiver_sid = trim($_POST['receiver_sid'] ?? '');
    $sender_name  = $_SESSION['display_name'] ?? 'Someone';

    if (!$room_id || !$receiver_sid) {
        echo json_encode(['ok' => false, 'error' => 'Invalid beep']); exit;
    }

    $pdo->prepare("INSERT INTO beeps (room_id, sender_sid, sender_name, receiver_sid) VALUES (?,?,?,?)")
        ->execute([$room_id, $sid, $sender_name, $receiver_sid]);

    echo json_encode(['ok' => true]);
    exit;
}

// ── Kick User (host only) ─────────────────────────────────
if ($action === 'kick_user') {
    $target_sid = trim($_POST['target_sid'] ?? '');
    $room_id    = $_SESSION['room_id'] ?? '';
    if ($_SESSION['role'] !== 'host' || !$room_id || !$target_sid) {
        echo json_encode(['ok' => false]); exit;
    }
    $pdo->prepare("UPDATE room_sessions SET is_online=0 WHERE sid=? AND room_id=?")->execute([$target_sid, $room_id]);

    $nsmt = $pdo->prepare("SELECT display_name FROM room_sessions WHERE sid=?");
    $nsmt->execute([$target_sid]);
    $nm = $nsmt->fetch();
    $name = $nm ? $nm['display_name'] : 'User';

    $pdo->prepare("INSERT INTO messages (msg_uuid, room_id, sender_sid, handle, display_name, color, role, message) VALUES (?,'system','system',?,?,'#505670','member',?)")
        ->execute([uuidv4(), $name, $name, "$name was removed by the host."]);

    // Insert a beep-type "kicked" event
    $pdo->prepare("INSERT INTO beeps (room_id, sender_sid, sender_name, receiver_sid, is_seen) VALUES (?,'system','__kicked',?,0)")
        ->execute([$room_id, $target_sid]);

    echo json_encode(['ok' => true]);
    exit;
}

// ── Leave Room ────────────────────────────────────────────
if ($action === 'leave') {
    $sid     = $MY_SID;
    $room_id = $_SESSION['room_id'] ?? '';
    $role    = $_SESSION['role'] ?? '';
    $name    = $_SESSION['display_name'] ?? 'User';

    if ($room_id) {
        if ($role === 'host') {
            $pdo->prepare("UPDATE rooms SET closed_at=NOW() WHERE room_id=?")->execute([$room_id]);
            $pdo->prepare("UPDATE room_sessions SET is_online=0 WHERE room_id=?")->execute([$room_id]);
        } else {
            $pdo->prepare("UPDATE room_sessions SET is_online=0 WHERE sid=?")->execute([$sid]);
            $pdo->prepare("INSERT INTO messages (msg_uuid, room_id, sender_sid, handle, display_name, color, role, message) VALUES (?,'system','system',?,?,'#505670','member',?)")
                ->execute([uuidv4(), $name, $name, "$name has left the room."]);
        }
    }

    session_destroy();
    echo json_encode(['ok' => true]);
    exit;
}

// ── Cancel Join Request ───────────────────────────────────
if ($action === 'cancel_join') {
    $sid     = $MY_SID;
    $room_id = $_SESSION['pending_room'] ?? '';
    if ($room_id) {
        $pdo->prepare("DELETE FROM pending_requests WHERE sid=? AND room_id=?")->execute([$sid, $room_id]);
    }
    unset($_SESSION['pending_room'], $_SESSION['pending_handle']);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Change Display Name ───────────────────────────────────
if ($action === 'change_name') {
    $new_name = trim($_POST['display_name'] ?? '');
    $sid      = $MY_SID;
    $room_id  = $_SESSION['room_id'] ?? '';

    if (!$new_name || strlen($new_name) > 40 || !$room_id) {
        echo json_encode(['ok' => false, 'error' => 'Invalid name']); exit;
    }

    $pdo->prepare("UPDATE room_sessions SET display_name=? WHERE sid=? AND room_id=?")->execute([$new_name, $sid, $room_id]);
    $_SESSION['display_name'] = $new_name;

    echo json_encode(['ok' => true, 'display_name' => $new_name]);
    exit;
}

// ── Session Info ─────────────────────────────────────────
if ($action === 'session_info') {
    if (!empty($_SESSION['room_id'])) {
        $sid = $MY_SID;
        $stmt = $pdo->prepare("SELECT * FROM room_sessions WHERE sid=? AND is_online=1");
        $stmt->execute([$sid]);
        $sess = $stmt->fetch();
        if ($sess) {
            echo json_encode([
                'in_room'      => true,
                'room_id'      => $_SESSION['room_id'],
                'handle'       => $_SESSION['handle'],
                'display_name' => $_SESSION['display_name'],
                'role'         => $_SESSION['role'],
                'color'        => $_SESSION['color'],
                'sid'          => $sid
            ]);
            exit;
        }
    }
    echo json_encode(['in_room' => false]);
    exit;
}

echo json_encode(['error' => 'Unknown action']);
?>
