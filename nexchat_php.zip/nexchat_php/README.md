# NexChat PHP Edition — Installation Guide

## 🚀 Setup on XAMPP (Local)

### Step 1 — Copy Files
Paste the `nexchat_php` folder into:
```
C:\xampp\htdocs\nexchat_php\
```

### Step 2 — Create Database
1. Start **Apache** + **MySQL** in XAMPP Control Panel
2. Open: `http://localhost/phpmyadmin`
3. Click **New** → Database name: `nexchat` → Create
4. Click **Import** → select `database.sql` → Go

### Step 3 — Open App
```
http://localhost/nexchat_php/
```

---

## 🌐 Online Server (cPanel)

1. Upload `nexchat_php` folder to `public_html/`
2. Import `database.sql` in phpMyAdmin
3. Edit `config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'your_db_user');
   define('DB_PASS', 'your_db_password');
   define('DB_NAME', 'nexchat');
   ```

---

## ✨ New Features Added

### 📳 Beep Button
- Click the **📳 button** in the chat input bar to beep everyone in the room
- Or hover over a member name → click the 📳 icon to beep just that person
- Receiver hears **3 escalating tones** + phone vibrates
- A full-screen popup appears on the receiver's side

### ✓✓ Read Receipts
- Your messages show **✓** (sent) when delivered
- Turns **✓✓ yellow** when the other person reads it
- Works automatically as messages scroll into view

### ✏️ Change Display Name
- Click the **✏️ pencil icon** next to your name in the sidebar
- Type a new name and click Save
- Your name updates everywhere in the room

---

## 📁 File Structure
```
nexchat_php/
├── index.php       ← Main UI (all screens)
├── api.php         ← All API endpoints
├── config.php      ← DB config + helpers
├── database.sql    ← DB schema
├── css/
│   └── style.css   ← Full stylesheet
├── js/
│   └── app.js      ← All client logic
└── README.md
```

---

## ⚙️ How It Works (PHP vs Python)

| Feature | Original (Python/Socket.IO) | PHP Version |
|---------|----------------------------|-------------|
| Real-time | WebSocket | HTTP Polling (1.5s) |
| Server | Flask + SocketIO | PHP + MySQL |
| Hosting | Needs Python | Any XAMPP/cPanel |
| Messages | In-memory | MySQL (persistent) |
| Encryption | None | AES session tokens |

---
NexChat PHP Edition — No Python Required!
